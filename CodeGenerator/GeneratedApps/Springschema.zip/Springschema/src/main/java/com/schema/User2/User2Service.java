package com.schemauser2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;
@Service
public class User2Service {
    private final User2Repository user2Repository;
    @Autowired
    public User2Service(User2Repository user2Repository) {
        this.user2Repository = user2Repository;
    }
    public User2 findById(String id) {
        Optional<User2> user2 = user2Repository.findById(id);
        return user2.orElse(null);
    }
    public User2 create(User2 user2) {
        return user2Repository.save(user2);
    }
    public User2 update(String id, User2 updatedUser2) {
        Optional<User2> existingUser2 = user2Repository.findById(id);
        if (existingUser2.isPresent()) {
            updatedUser2.setId(id);
            return user2Repository.save(updatedUser2);
        }
        return null;
    }
    public List<User2> getAll() {
        return user2Repository.findAll();
    }
    public boolean deleteById(String id) {
        Optional<User2> user2 = user2Repository.findById(id);
        if (user2.isPresent()) {
        user2Repository.deleteById(id);
            return true;
        }
        return false;
    }
}
