package com.schemauser2;
import java.io.Serializable;
import javax.persistence.*;


//#{IMPORT_COLUMN_TYPES}#
import com.fasterxml.jackson.annotation.JsonBackReference;
import java.util.*;
@Entity
@Table(name = "User2")
public class User2 {
        private static final long serialVersionUID = 1L;
@Id
@Column(name="username")
private String username;
 
@Column(name="firstName")
private String firstName;
 
@Column(name="age")
private Integer age;
 
@Column(name="passportID")
private Integer passportID;
 


        public User2() {
        }
public void setUsername(String username) {
		this.username = username;
	}
public String  getUsername() {
		return username;
	}
public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
public String  getFirstName() {
		return firstName;
	}
public void setAge(Integer age) {
		this.age = age;
	}
public Integer  getAge() {
		return age;
	}
public void setPassportID(Integer passportID) {
		this.passportID = passportID;
	}
public Integer  getPassportID() {
		return passportID;
	}


}
