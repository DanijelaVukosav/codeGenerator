package com.schemauser1;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;
@Service
public class User1Service {
    private final User1Repository user1Repository;
    @Autowired
    public User1Service(User1Repository user1Repository) {
        this.user1Repository = user1Repository;
    }
    public User1 findById(String id) {
        Optional<User1> user1 = user1Repository.findById(id);
        return user1.orElse(null);
    }
    public User1 create(User1 user1) {
        return user1Repository.save(user1);
    }
    public User1 update(String id, User1 updatedUser1) {
        Optional<User1> existingUser1 = user1Repository.findById(id);
        if (existingUser1.isPresent()) {
            updatedUser1.setId(id);
            return user1Repository.save(updatedUser1);
        }
        return null;
    }
    public List<User1> getAll() {
        return user1Repository.findAll();
    }
    public boolean deleteById(String id) {
        Optional<User1> user1 = user1Repository.findById(id);
        if (user1.isPresent()) {
        user1Repository.deleteById(id);
            return true;
        }
        return false;
    }
}
