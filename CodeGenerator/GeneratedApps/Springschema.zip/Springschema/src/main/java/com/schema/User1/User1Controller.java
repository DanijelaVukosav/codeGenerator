package com.schemauser1;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;
@RestController
@RequestMapping("/api/data/User1")
public class User1Controller {
    private final User1Service user1Service;
    @Autowired
    public User1Controller(User1Service user1Service) {
        this.user1Service = user1Service;
    }
    @GetMapping("/{id}")
    public ResponseEntity<User1> getUser1ById(@PathVariable String id) {
        User1 user1 = user1Service.findById(id);
        if (user1 != null) {
            return ResponseEntity.ok().body(user1);
        } else {
            return ResponseEntity.notFound().build();
        }
    }
    @PostMapping
    public ResponseEntity<User1> createUser1(@RequestBody User1 user1) {
        User1 createdUser1 = user1Service.create(user1);
        return ResponseEntity.status(HttpStatus.CREATED).body(createdUser1);
    }
    @PutMapping("/{id}")
    public ResponseEntity<User1> updateUser1(@PathVariable String id, @RequestBody User1 updatedUser1) {
        User1 user1 = user1Service.update(id, updatedUser1);
        if (user1 != null) {
            return ResponseEntity.ok().body(user1);
        } else {
            return ResponseEntity.notFound().build();
        }
    }
    @GetMapping
    public ResponseEntity<List<User1>> getAllUser1s() {
        List<User1> user1s = user1Service.getAll();
        return ResponseEntity.ok().body(user1s);
    }
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteUser1(@PathVariable String id) {
        boolean deleted = user1Service.deleteById(id);
        if (deleted) {
            return ResponseEntity.noContent().build();
        } else {
            return ResponseEntity.notFound().build();
        }
    }
}
