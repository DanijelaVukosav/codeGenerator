package com.schemauser2;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;
@RestController
@RequestMapping("/api/data/User2")
public class User2Controller {
    private final User2Service user2Service;
    @Autowired
    public User2Controller(User2Service user2Service) {
        this.user2Service = user2Service;
    }
    @GetMapping("/{id}")
    public ResponseEntity<User2> getUser2ById(@PathVariable String id) {
        User2 user2 = user2Service.findById(id);
        if (user2 != null) {
            return ResponseEntity.ok().body(user2);
        } else {
            return ResponseEntity.notFound().build();
        }
    }
    @PostMapping
    public ResponseEntity<User2> createUser2(@RequestBody User2 user2) {
        User2 createdUser2 = user2Service.create(user2);
        return ResponseEntity.status(HttpStatus.CREATED).body(createdUser2);
    }
    @PutMapping("/{id}")
    public ResponseEntity<User2> updateUser2(@PathVariable String id, @RequestBody User2 updatedUser2) {
        User2 user2 = user2Service.update(id, updatedUser2);
        if (user2 != null) {
            return ResponseEntity.ok().body(user2);
        } else {
            return ResponseEntity.notFound().build();
        }
    }
    @GetMapping
    public ResponseEntity<List<User2>> getAllUser2s() {
        List<User2> user2s = user2Service.getAll();
        return ResponseEntity.ok().body(user2s);
    }
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteUser2(@PathVariable String id) {
        boolean deleted = user2Service.deleteById(id);
        if (deleted) {
            return ResponseEntity.noContent().build();
        } else {
            return ResponseEntity.notFound().build();
        }
    }
}
