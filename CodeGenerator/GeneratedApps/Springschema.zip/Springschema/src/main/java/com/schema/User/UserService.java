package com.schemauser;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;
@Service
public class UserService {
    private final UserRepository userRepository;
    @Autowired
    public UserService(UserRepository userRepository) {
        this.userRepository = userRepository;
    }
    public User findById(String id) {
        Optional<User> user = userRepository.findById(id);
        return user.orElse(null);
    }
    public User create(User user) {
        return userRepository.save(user);
    }
    public User update(String id, User updatedUser) {
        Optional<User> existingUser = userRepository.findById(id);
        if (existingUser.isPresent()) {
            updatedUser.setId(id);
            return userRepository.save(updatedUser);
        }
        return null;
    }
    public List<User> getAll() {
        return userRepository.findAll();
    }
    public boolean deleteById(String id) {
        Optional<User> user = userRepository.findById(id);
        if (user.isPresent()) {
        userRepository.deleteById(id);
            return true;
        }
        return false;
    }
}
