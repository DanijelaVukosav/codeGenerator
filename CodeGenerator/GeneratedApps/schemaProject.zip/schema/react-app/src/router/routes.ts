export const HOME_ROUTE = "/";

export const APPLICATION_ROUTES = {
KORISNICI:  "/korisnici",
PROIZVODI:  "/proizvodi",
NARUDZBE:  "/narudzbe",
  SYSTEM_USERS: "/system_users",

  LOGOUT: "/logout",
  LOGIN: "/login",
};
