export class HOME_ROUTE {

}