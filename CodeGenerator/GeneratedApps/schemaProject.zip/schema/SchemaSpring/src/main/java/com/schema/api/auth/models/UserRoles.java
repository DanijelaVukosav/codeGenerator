package com.schema.api.auth.models;

public class UserRoles {
}
