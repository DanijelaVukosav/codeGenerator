package com.schema.api.audit;

//import com.fasterxml.jackson.datatype.hibernate5.Hibernate5Module;

//@Configuration
public class JacksonConfig {
//    @Bean
//    public Hibernate5Module hibernate5Module() {
//        Hibernate5Module hibernate5Module = new Hibernate5Module();
//        hibernate5Module.configure(Hibernate5Module.Feature.SERIALIZE_IDENTIFIER_FOR_LAZY_NOT_LOADED_OBJECTS, true);
//        return hibernate5Module;
//        return new Hibernate5Module();
//    }
}
